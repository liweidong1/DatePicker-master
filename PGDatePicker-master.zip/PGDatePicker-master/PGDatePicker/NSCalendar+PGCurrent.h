//
//  NSCalendar+PGCurrent.h
//  HooDatePickerDemo
//
//  Created by piggybear on 2017/7/25.
//  Copyright © 2017年 piggybear. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (PGCurrent)
@property (nonatomic, strong) NSDateComponents *currentComponents;
@end
